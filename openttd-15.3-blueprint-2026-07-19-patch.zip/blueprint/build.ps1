<#
.SYNOPSIS
    Build OpenTTD (with the Blueprint patch) on Windows - the counterpart to build.sh.

.DESCRIPTION
    Configures and builds the source tree that contains this script, using whatever
    Visual Studio (2022 or newer) is installed and vcpkg. Dependencies are installed
    automatically: the tree ships
    a vcpkg.json manifest, so configuring pulls in breakpad, liblzma, libpng, lzo,
    opusfile and zlib by itself. The first build therefore takes a long time
    (roughly 30-60 minutes) while vcpkg compiles those from source; later builds
    are quick.

    The build directory defaults to 'build-windows', deliberately NOT 'build':
    when the tree is shared with Linux (a VM share, say) 'build' already holds a
    Linux CMake cache, and pointing Windows CMake at it fails.

.PARAMETER Config
    Release (default), Debug, RelWithDebInfo or MinSizeRel.

.PARAMETER BuildDir
    Build directory. Defaults to <source>\build-windows.

.PARAMETER VcpkgRoot
    Where vcpkg is installed. Defaults to $env:VCPKG_ROOT, then common locations.

.PARAMETER Triplet
    vcpkg triplet. Defaults to x64-windows-static (what OpenTTD's docs advise).

.PARAMETER RunTests
    Run the test suite after building.

.EXAMPLE
    .\build.ps1
.EXAMPLE
    .\build.ps1 -Config Debug -RunTests
.EXAMPLE
    .\build.ps1 -VcpkgRoot C:\vcpkg -- -DOPTION_DEDICATED=ON
#>
[CmdletBinding()]
param(
    [ValidateSet('Release', 'Debug', 'RelWithDebInfo', 'MinSizeRel')]
    [string]$Config = 'Release',
    [string]$BuildDir,
    [string]$VcpkgRoot,
    [string]$Triplet = 'x64-windows-static',
    [switch]$RunTests,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$CMakeArgs
)

$ErrorActionPreference = 'Stop'

function Write-Step($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Warn($msg) { Write-Host "    $msg" -ForegroundColor Yellow }

# ---------------------------------------------------------------- source root
# Same convention as build.sh: the script sits in blueprint/ inside the tree,
# or has been copied to the tree root.
$root = $PSScriptRoot
if (-not (Test-Path (Join-Path $root 'CMakeLists.txt'))) {
    $parent = Split-Path $root -Parent
    if (Test-Path (Join-Path $parent 'CMakeLists.txt')) {
        $root = $parent
    } else {
        throw "Cannot find the OpenTTD source tree (no CMakeLists.txt in '$root' or its parent)."
    }
}
if (-not $BuildDir) { $BuildDir = Join-Path $root 'build-windows' }

Write-Step "Source tree : $root"
Write-Step "Build dir   : $BuildDir"
Write-Step "Config      : $Config    Triplet: $Triplet"

# --------------------------------------------------------------- preconditions
$missing = @()

$cmake = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $cmake) {
    $missing += "CMake 3.17+ - install from https://cmake.org/download/ (or the 'C++ CMake tools' component of Visual Studio) and make sure it is on PATH."
}

# Visual Studio (2022 or newer) with the C++ toolset, located via vswhere.
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$vsInstall = $null
$vsVersion = $null
if (Test-Path $vswhere) {
    $vsInstall = & $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationPath 2>$null
    $vsVersion = & $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationVersion 2>$null
}
if (-not $vsInstall) {
    $missing += "Visual Studio 2022 or newer with the 'Desktop development with C++' workload - https://visualstudio.microsoft.com/vs/community/"
}

# CMake's -G generator name is tied to the VS major version (e.g. 17 -> 2022,
# 18 -> 2026). vswhere's -products * accepts whatever VS is installed, so pick
# the matching generator rather than assuming one release - a hardcoded 2022
# generator fails with an MSB8020 v143-toolset error against a newer/older VS.
$vsGeneratorByMajor = @{
    '14' = 'Visual Studio 14 2015'
    '15' = 'Visual Studio 15 2017'
    '16' = 'Visual Studio 16 2019'
    '17' = 'Visual Studio 17 2022'
    '18' = 'Visual Studio 18 2026'
}
$generator = $null
if ($vsVersion) {
    $vsMajor = ($vsVersion -split '\.')[0]
    $generator = $vsGeneratorByMajor[$vsMajor]
    if (-not $generator) {
        $missing += "No known CMake generator for the installed Visual Studio version ($vsVersion) - add 'Visual Studio $vsMajor <year>' to `$vsGeneratorByMajor in build.ps1."
    }
}

# vcpkg: parameter, environment, then the usual places.
if (-not $VcpkgRoot) { $VcpkgRoot = $env:VCPKG_ROOT }
if (-not $VcpkgRoot) {
    foreach ($candidate in @('C:\vcpkg', 'C:\dev\vcpkg', 'C:\src\vcpkg',
                             (Join-Path $env:USERPROFILE 'vcpkg'))) {
        if (Test-Path (Join-Path $candidate 'scripts\buildsystems\vcpkg.cmake')) {
            $VcpkgRoot = $candidate
            break
        }
    }
}
$toolchain = $null
if ($VcpkgRoot) { $toolchain = Join-Path $VcpkgRoot 'scripts\buildsystems\vcpkg.cmake' }
if (-not $toolchain -or -not (Test-Path $toolchain)) {
    $missing += @"
vcpkg - install it and either set VCPKG_ROOT or pass -VcpkgRoot:
      git clone https://github.com/microsoft/vcpkg C:\vcpkg
      C:\vcpkg\bootstrap-vcpkg.bat
    (No 'vcpkg install' needed: this tree has a vcpkg.json manifest, so
     configuring installs the dependencies by itself.)
"@
}

# git is what vcpkg uses to fetch its registry/baseline.
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    $missing += "Git for Windows - https://git-scm.com/download/win (vcpkg needs it)"
}

if ($missing.Count) {
    Write-Host ''
    Write-Host 'Missing prerequisites:' -ForegroundColor Red
    foreach ($m in $missing) { Write-Host "  * $m" -ForegroundColor Red }
    Write-Host ''
    throw 'Install the above, then run this script again.'
}

Write-Step "Visual Studio: $vsInstall ($vsVersion, generator: $generator)"
Write-Step "vcpkg        : $VcpkgRoot"

# A build directory carried over from another OS, or configured with a
# different VS generator (e.g. a previous run against an older/newer VS, or a
# failed first attempt before this script picked the right one), cannot be
# reused - CMake refuses to reconfigure over either mismatch.
$cache = Join-Path $BuildDir 'CMakeCache.txt'
if (Test-Path $cache) {
    $homeMatch = Select-String -Path $cache -Pattern '^CMAKE_HOME_DIRECTORY:INTERNAL=(.+)$' |
                 Select-Object -First 1
    $homeDir = if ($homeMatch) { $homeMatch.Matches[0].Groups[1].Value } else { $null }
    $genMatch = Select-String -Path $cache -Pattern '^CMAKE_GENERATOR:INTERNAL=(.+)$' |
                Select-Object -First 1
    $cachedGenerator = if ($genMatch) { $genMatch.Matches[0].Groups[1].Value } else { $null }
    if ($homeDir -and ($homeDir -match '^/' -or -not (Test-Path $homeDir))) {
        Write-Warn "'$BuildDir' holds a CMake cache from another machine or OS; removing it."
        Remove-Item -Recurse -Force $BuildDir
    } elseif ($cachedGenerator -and $cachedGenerator -ne $generator) {
        Write-Warn "'$BuildDir' was configured with generator '$cachedGenerator', not '$generator'; removing it."
        Remove-Item -Recurse -Force $BuildDir
    }
}

# ------------------------------------------------------------------- configure
Write-Step 'Configuring (first run also builds the vcpkg dependencies - be patient)'
$configureArgs = @(
    '-S', $root,
    '-B', $BuildDir,
    '-G', $generator,
    '-A', 'x64',
    "-DCMAKE_TOOLCHAIN_FILE=$toolchain",
    "-DVCPKG_TARGET_TRIPLET=$Triplet"
)
if ($CMakeArgs) { $configureArgs += ($CMakeArgs | Where-Object { $_ -ne '--' }) }

& cmake @configureArgs
if ($LASTEXITCODE -ne 0) { throw "CMake configure failed (exit $LASTEXITCODE)." }

# ----------------------------------------------------------------------- build
Write-Step "Building ($Config)"
& cmake --build $BuildDir --config $Config --parallel
if ($LASTEXITCODE -ne 0) { throw "Build failed (exit $LASTEXITCODE)." }

# ----------------------------------------------------------------------- tests
if ($RunTests) {
    Write-Step 'Running tests'
    & ctest --test-dir $BuildDir -C $Config --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw "Tests failed (exit $LASTEXITCODE)." }
}

# ---------------------------------------------------------------------- result
$exe = Get-ChildItem -Path $BuildDir -Filter 'openttd.exe' -Recurse -File -ErrorAction SilentlyContinue |
       Select-Object -First 1
Write-Host ''
if ($exe) {
    Write-Host "Build finished ($Config): $($exe.FullName)" -ForegroundColor Green
    # lang/baseset/ai/game are generated under $BuildDir itself, not under the
    # per-config subfolder the VS generator puts the exe in - OpenTTD resolves
    # them relative to the working directory, so the exe must be launched with
    # $BuildDir as cwd (this is also why VS_DEBUGGER_WORKING_DIRECTORY is set
    # to it in CMakeLists.txt: F5 in Visual Studio gets this right automatically).
    # Running the exe directly from another cwd fails with "No available
    # language packs".
    Write-Host "Start the game with (must run with the build dir as cwd):"
    Write-Host "  Set-Location '$BuildDir'; & '$($exe.FullName)'"
} else {
    Write-Warn "Build reported success but openttd.exe was not found under $BuildDir."
}

#!/usr/bin/env bash
# Build a portable Linux AppImage of OpenTTD with the Blueprint patch - the
# counterpart to build.sh (plain Linux build), build.ps1 (Windows) and
# build-macos.sh (macOS).
#
# Usage:
#   ./build-appimage.sh                       # AppImage into build-appimage/
#   ./build-appimage.sh -o /tmp/out.AppImage  # write it somewhere specific
#   ./build-appimage.sh --engine docker       # use docker instead of podman
#   ./build-appimage.sh --keep-appdir         # leave the AppDir for inspection
#
# The build runs inside a Debian 12 container, NOT on the host, because an
# AppImage bundles libraries but never glibc: a binary built against a recent
# glibc refuses to start on any older distribution, no matter what is bundled.
# Debian 12 (glibc 2.36) yields a floor of GLIBC_2.34, which covers Ubuntu
# 22.04+, Debian 12+, Fedora 35+ and RHEL 9+.
#
# Three corrections are applied that OpenTTD's own OPTION_PACKAGE_DEPENDENCIES
# packaging does not make; each one was an actual startup failure on some
# distribution before it was fixed. They are documented at the point where they
# happen, further down.
set -euo pipefail

# Resolve our own path before any cd, so --help can still read this file.
SCRIPT_PATH="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"

# The source root is either the script's own directory (when copied there) or,
# when run from blueprint/ inside the tree, the parent directory.
cd "$(dirname "$0")"
if [[ ! -f CMakeLists.txt && -f ../CMakeLists.txt ]]; then
	cd ..
fi
SOURCE_DIR="$PWD"

# Deliberately not "build": that directory holds the host's own CMake cache,
# which the container's CMake cannot reuse.
BUILD_ROOT="$SOURCE_DIR/build-appimage"

BUILD_IMAGE="docker.io/library/debian:12"
# Only used to source one library, see "correction 2" below.
EXPAT_IMAGE="docker.io/library/ubuntu:22.04"
APPIMAGETOOL_URL="https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage"

ENGINE=""
OUTPUT=""
KEEP_APPDIR=false

while [[ $# -gt 0 ]]; do
	case "$1" in
		-o|--output)
			OUTPUT="${2:-}"; shift 2 ;;
		--engine)
			ENGINE="${2:-}"; shift 2 ;;
		--keep-appdir)
			KEEP_APPDIR=true; shift ;;
		-h|--help)
			sed -n '2,21p' "$SCRIPT_PATH" | sed 's/^# \{0,1\}//'; exit 0 ;;
		*)
			echo "Error: unknown argument '$1' (try --help)." >&2; exit 1 ;;
	esac
done

# ------------------------------------------------------------- preconditions
missing=()

if [[ -z "$ENGINE" ]]; then
	if command -v podman >/dev/null 2>&1; then
		ENGINE=podman
	elif command -v docker >/dev/null 2>&1; then
		ENGINE=docker
	else
		missing+=("podman or docker (the build runs in a container)")
	fi
elif ! command -v "$ENGINE" >/dev/null 2>&1; then
	missing+=("$ENGINE (passed via --engine, but not on PATH)")
fi

command -v curl >/dev/null 2>&1 || missing+=("curl (to fetch appimagetool)")

if [[ ${#missing[@]} -gt 0 ]]; then
	echo "Missing prerequisites:" >&2
	for m in "${missing[@]}"; do echo "  * $m" >&2; done
	exit 1
fi

# Rootless podman needs subuid/subgid ranges for the CURRENT user name; a
# leftover entry for a differently-cased name does not count. Without them the
# image unpack fails with a confusing chown error, so check up front.
if [[ "$ENGINE" == "podman" ]] && ! grep -q "^$(id -un):" /etc/subuid 2>/dev/null; then
	echo "Error: rootless podman has no subuid range for user '$(id -un)'." >&2
	echo "Fix with:" >&2
	echo "  sudo usermod --add-subuids 100000-165535 --add-subgids 100000-165535 $(id -un)" >&2
	echo "  podman system migrate" >&2
	exit 1
fi

VERSION="$(sed -n 's/.*BLUEPRINT_PATCH_VERSION = "\([^"]*\)".*/\1/p' "$SOURCE_DIR/src/blueprint_version.h")"
if [[ -z "$VERSION" ]]; then
	echo "Error: could not read BLUEPRINT_PATCH_VERSION from src/blueprint_version.h." >&2
	echo "Is the Blueprint patch applied to this tree? See blueprint/apply-patch.sh" >&2
	exit 1
fi

# The OpenTTD release this tree is, for the file name; .version is what the
# release tarball ships and what the build itself falls back on.
OPENTTD_VERSION="$(tr -d '[:space:]' < "$SOURCE_DIR/.version" 2>/dev/null || true)"
[[ -n "$OPENTTD_VERSION" ]] || OPENTTD_VERSION="unknown"

# Defaults into build-appimage/ rather than the source root: /build* is
# gitignored, so the result does not show up as an untracked file in the tree.
[[ -n "$OUTPUT" ]] || OUTPUT="$BUILD_ROOT/openttd-${OPENTTD_VERSION}-blueprint-${VERSION}-linux-x86_64.AppImage"

APPDIR="$BUILD_ROOT/AppDir"
mkdir -p "$BUILD_ROOT"
rm -rf "$APPDIR"

echo "Source      : $SOURCE_DIR"
echo "Build root  : $BUILD_ROOT"
echo "Version     : $VERSION"
echo "Engine      : $ENGINE   Image: $BUILD_IMAGE"
echo "Output      : $OUTPUT"
echo

# ------------------------------------------------------- container build step
# Written to a file rather than passed with -c, so quoting stays readable.
cat > "$BUILD_ROOT/in-container-build.sh" <<'CONTAINER_EOF'
#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
# openttd-opengfx is not a build dependency: the two AI/GS regression tests
# actually start the game, which refuses to run without a base graphics set.
# Without it they fail with "Failed to find a graphics set" and every line of
# their expected output mismatches.
apt-get install -y --no-install-recommends \
	build-essential cmake pkg-config file ca-certificates binutils \
	libsdl2-dev zlib1g-dev liblzma-dev liblzo2-dev libpng-dev \
	libfreetype-dev libfontconfig1-dev libicu-dev libharfbuzz-dev \
	libcurl4-openssl-dev openttd-opengfx

# The flat (non-FHS) layout puts openttd next to baseset/, lang/, ai/ and
# game/, which is how the binary expects to find its data files.
#
# The RPATH is set by hand instead of via OPTION_PACKAGE_DEPENDENCIES: that
# option additionally installs the resolved libraries itself, which fails on a
# bind-mounted destination, and its exclude list needs correcting anyway (see
# below). Setting it here gives the same $ORIGIN/lib lookup without that step.
cmake -S /src -B /build \
	-DCMAKE_BUILD_TYPE=Release \
	-DOPTION_INSTALL_FHS=OFF \
	-DCMAKE_INSTALL_RPATH='$ORIGIN/lib' \
	-DCMAKE_BUILD_WITH_INSTALL_RPATH=ON \
	-DCMAKE_INSTALL_PREFIX=/out/AppDir/usr

cmake --build /build -j"$(nproc)"

# The game looks for base sets next to its own binary, so put the packaged
# OpenGFX where the freshly built one will find it.
cp -r /usr/share/games/openttd/baseset/opengfx /build/baseset/

# Prove the build is sound, not merely that it linked.
ctest --test-dir /build --output-on-failure -j"$(nproc)"

# Drop it again before installing: the install step copies the whole baseset
# directory, and OpenGFX is only wanted for the tests, not inside the AppImage.
# Players get a base set through the game's own first-run download.
rm -rf /build/baseset/opengfx

cmake --install /build

BIN=/out/AppDir/usr/openttd
LIB=/out/AppDir/usr/lib
mkdir -p "$LIB"

# Correction 1: libresolv is part of glibc, and shipping one distribution's
# copy against another's glibc fails with "GLIBC_ABI_DT_RELR not found".
# OpenTTD's own exclude list covers libc/libdl/libm/libpthread/librt but misses
# it, which does not show up upstream because they build on their oldest
# supported distribution. libstdc++ is likewise left to the host, on purpose.
EXCLUDE='ld-linux|libc\.so|libdl\.so|libm\.so|libgcc_s\.so|libpthread\.so|librt\.so|libstdc\+\+\.so|libresolv\.so|libnsl\.so|libanl\.so|libutil\.so'

ldd "$BIN" | awk '/=> \//{print $1 "\t" $3}' | while IFS=$'\t' read -r soname path; do
	if echo "$soname" | grep -qE "$EXCLUDE"; then
		continue
	fi
	# Copy the real file under its SONAME, which is what the loader looks up.
	cp -L "$path" "$LIB/$soname"
done

echo "Bundled $(ls "$LIB" | wc -l) libraries."
CONTAINER_EOF
chmod +x "$BUILD_ROOT/in-container-build.sh"

mkdir -p "$BUILD_ROOT/out"
rm -rf "$BUILD_ROOT/out/AppDir"

echo "==> Building in $BUILD_IMAGE (this takes a while: full compile plus toolchain install)"
"$ENGINE" run --rm \
	-v "$SOURCE_DIR":/src:ro,Z \
	-v "$BUILD_ROOT/out":/out:Z \
	-v "$BUILD_ROOT/in-container-build.sh":/build.sh:ro,Z \
	"$BUILD_IMAGE" /build.sh

mv "$BUILD_ROOT/out/AppDir" "$APPDIR"

# Correction 2: Debian 12's libexpat requires GLIBC_2.36, which would raise the
# floor for the whole AppImage above that of the binary itself. It cannot
# simply be left out either - minimal systems do not have it. Take the copy
# from an older distribution instead, where it needs only GLIBC_2.25.
echo "==> Fetching a lower-glibc libexpat from $EXPAT_IMAGE"
"$ENGINE" run --rm -v "$APPDIR/usr/lib":/lib-out:Z "$EXPAT_IMAGE" sh -c '
	set -e
	export DEBIAN_FRONTEND=noninteractive
	apt-get update -qq >/dev/null
	apt-get install -y --no-install-recommends libexpat1 >/dev/null
	cp -L /lib/x86_64-linux-gnu/libexpat.so.1 /lib-out/libexpat.so.1
'

# ------------------------------------------------------------ AppDir metadata
# Correction 3: DT_RUNPATH applies only to an object's OWN direct
# dependencies, never transitively. Without LD_LIBRARY_PATH a bundled library
# (libcurl, say) looks up ITS dependencies (librtmp, ...) against the host and
# fails wherever those are absent.
cat > "$APPDIR/AppRun" <<'APPRUN_EOF'
#!/bin/sh
# AppRun for OpenTTD with the Blueprint patch.
#
# LD_LIBRARY_PATH rather than the binary's RUNPATH alone: DT_RUNPATH is not
# inherited by the bundled libraries' own lookups. OpenTTD finds baseset/,
# lang/, ai/ and game/ relative to the binary, so exec'ing it in place is all
# that is otherwise needed.
set -e

HERE="$(dirname "$(readlink -f "$0")")"

export LD_LIBRARY_PATH="${HERE}/usr/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}"

exec "${HERE}/usr/openttd" "$@"
APPRUN_EOF
chmod +x "$APPDIR/AppRun"

# Named "OpenTTD Blueprint" so it does not collide with a normal OpenTTD
# installation in application menus.
cat > "$APPDIR/openttd-blueprint.desktop" <<'DESKTOP_EOF'
[Desktop Entry]
Type=Application
Version=1.0
Name=OpenTTD Blueprint
GenericName=Transport Simulation
Comment=OpenTTD 15.3 with the Blueprint patch: copy and paste your infrastructure
Icon=openttd-blueprint
Exec=AppRun
Terminal=false
Categories=Game;Simulation;
Keywords=game;simulation;transport;tycoon;deluxe;economics;multiplayer;money;train;ship;bus;truck;aircraft;cargo;blueprint;
DESKTOP_EOF

cp "$APPDIR/usr/share/icons/hicolor/256x256/apps/openttd.png" "$APPDIR/openttd-blueprint.png"

# ---------------------------------------------------------------- appimagetool
APPIMAGETOOL="$BUILD_ROOT/appimagetool"
if [[ ! -x "$APPIMAGETOOL" ]]; then
	echo "==> Downloading appimagetool"
	curl -sSL -o "$APPIMAGETOOL" "$APPIMAGETOOL_URL"
	chmod +x "$APPIMAGETOOL"
fi

echo "==> Packaging"
rm -f "$OUTPUT"
ARCH=x86_64 "$APPIMAGETOOL" "$APPDIR" "$OUTPUT"

# --------------------------------------------------------------------- verify
# The glibc floor is the highest requirement across the binary AND every
# bundled library - a single stale library raises it for the whole AppImage.
FLOOR="$( { objdump -T "$APPDIR/usr/openttd"; for f in "$APPDIR/usr/lib"/*.so*; do objdump -T "$f" 2>/dev/null; done; } \
	| grep -oE 'GLIBC_[0-9]+\.[0-9]+' | sort -uV | tail -1 )"

echo
echo "==> Smoke test"
if ! "$OUTPUT" -h >/dev/null 2>&1; then
	echo "Error: the AppImage was built but does not run on this host." >&2
	exit 1
fi

if [[ "$KEEP_APPDIR" != true ]]; then
	rm -rf "$APPDIR" "$BUILD_ROOT/out"
fi

echo
echo "AppImage : $OUTPUT"
echo "Version  : $VERSION"
echo "Requires : $FLOOR or newer"
echo
echo "Test it on the oldest distribution you care about before publishing, e.g.:"
echo "  $ENGINE run --rm -e APPIMAGE_EXTRACT_AND_RUN=1 -v \"\$(dirname "$OUTPUT")\":/rel:ro,Z \\"
echo "      docker.io/library/ubuntu:22.04 sh -c 'cd /tmp && cp /rel/$(basename "$OUTPUT") . && ./$(basename "$OUTPUT") -h | head -3'"

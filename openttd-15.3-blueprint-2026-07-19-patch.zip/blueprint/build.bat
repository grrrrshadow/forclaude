@echo off
rem Build OpenTTD (with the Blueprint patch) on Windows.
rem
rem A thin wrapper around build.ps1 so this can be double-clicked or run from
rem cmd.exe without changing the PowerShell execution policy. Arguments are
rem passed straight through, e.g.:
rem
rem   build.bat                       Release build
rem   build.bat -Config Debug         Debug build
rem   build.bat -RunTests             build, then run the test suite
rem
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
    echo.
    echo Build failed with exit code %EXITCODE%.
)
rem Keep the window open when double-clicked from Explorer.
echo %CMDCMDLINE% | find /i "/c" >nul && pause
exit /b %EXITCODE%

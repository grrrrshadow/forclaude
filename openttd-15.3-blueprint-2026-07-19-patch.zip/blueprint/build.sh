#!/usr/bin/env bash
# Build OpenTTD from source into ./build.
#
# Usage:
#   ./build.sh                       # Release build (fast, playable)
#   ./build.sh Debug                 # Debug build with asserts (slow, for debugging)
#   ./build.sh Release -DOPTION_DEDICATED=ON   # extra args are passed to cmake
set -euo pipefail

cd "$(dirname "$0")"
SCRIPT_DIR="$PWD"

# The source root is either the script's own directory (when copied there) or,
# when run from blueprint/ inside the tree, the parent directory.
if [[ ! -f CMakeLists.txt && -f ../CMakeLists.txt ]]; then
	cd ..
fi

BUILD_TYPE="Release"
if [[ $# -gt 0 ]]; then
	case "$1" in
		Debug|Release|RelWithDebInfo|MinSizeRel)
			BUILD_TYPE="$1"
			shift
			;;
	esac
fi

BUILD_DIR="build"

cmake -S . -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE="$BUILD_TYPE" "$@"
cmake --build "$BUILD_DIR" -j"$(nproc)"

echo
echo "Build finished (${BUILD_TYPE}): ${BUILD_DIR}/openttd"
echo "Start the game with: ${SCRIPT_DIR}/run.sh"

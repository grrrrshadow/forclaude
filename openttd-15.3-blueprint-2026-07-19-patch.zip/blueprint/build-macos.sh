#!/usr/bin/env bash
# Build OpenTTD (with the Blueprint patch) on macOS - the counterpart to
# build.sh (Linux) and build.ps1 (Windows).
#
# Usage:
#   ./build-macos.sh                    # universal binary: Apple Silicon + Intel
#   ./build-macos.sh --native           # host architecture only (fast)
#   ./build-macos.sh --arch arm64       # a single architecture
#   ./build-macos.sh Debug              # build type (default Release)
#   ./build-macos.sh --native -DOPTION_DEDICATED=ON    # extra args go to cmake
#
# A universal binary needs every dependency compiled for BOTH architectures,
# which Homebrew cannot provide (it installs one architecture at a time), so
# that path uses vcpkg with its arm64-osx / x64-osx triplets - the same approach
# OpenTTD's own release-macos.yml workflow uses. --native has no such need and
# builds against whatever CMake finds, so it is much quicker for development.
#
# Either Mac can build both slices: an Apple Silicon machine produces the Intel
# binary and vice versa.
set -euo pipefail

# Resolve our own path before any cd, so --help can still read this file.
SCRIPT_PATH="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"

# The source root is either the script's own directory (when copied there) or,
# when run from blueprint/ inside the tree, the parent directory.
cd "$(dirname "$0")"
if [[ ! -f CMakeLists.txt && -f ../CMakeLists.txt ]]; then
	cd ..
fi
SOURCE_DIR="$PWD"

# Deliberately not "build": when the tree is shared with another OS (a VM
# share), build/ already holds that system's CMake cache, which cannot be reused.
BUILD_ROOT="$SOURCE_DIR/build-macos"

BUILD_TYPE="Release"
MODE="universal"
SINGLE_ARCH=""
CMAKE_EXTRA=()

while [[ $# -gt 0 ]]; do
	case "$1" in
		Debug|Release|RelWithDebInfo|MinSizeRel)
			BUILD_TYPE="$1"; shift ;;
		--native)
			MODE="native"; shift ;;
		--arch)
			MODE="single"; SINGLE_ARCH="${2:-}"; shift 2
			if [[ "$SINGLE_ARCH" != "arm64" && "$SINGLE_ARCH" != "x86_64" ]]; then
				echo "Error: --arch takes 'arm64' or 'x86_64'." >&2
				exit 1
			fi ;;
		-h|--help)
			sed -n '2,18p' "$SCRIPT_PATH" | sed 's/^# \{0,1\}//'; exit 0 ;;
		*)
			CMAKE_EXTRA+=("$1"); shift ;;
	esac
done

# Older macOS releases stay supported; the arm64 slice silently gets 11.0, which
# is the earliest that architecture exists on.
export MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-10.15}"

# ------------------------------------------------------------- preconditions
if [[ "$(uname -s)" != "Darwin" ]]; then
	echo "Error: this script only runs on macOS. Apple's SDK cannot legally or" >&2
	echo "practically be used to cross-compile from Linux or Windows; build on a" >&2
	echo "Mac, or use GitHub's macOS CI runners." >&2
	exit 1
fi

missing=()
xcode-select -p >/dev/null 2>&1 || missing+=("Xcode command line tools - install with: xcode-select --install")
command -v cmake >/dev/null 2>&1 || missing+=("CMake 3.17+ - install with: brew install cmake")
command -v git   >/dev/null 2>&1 || missing+=("git")

# Written as an if-block on purpose: under `set -e` a bare `[[ test ]] && VAR=x`
# aborts the script whenever the test is false.
NEEDS_VCPKG=false
if [[ "$MODE" == "universal" ]]; then
	NEEDS_VCPKG=true
elif [[ "$MODE" == "single" && "$SINGLE_ARCH" != "$(uname -m)" ]]; then
	NEEDS_VCPKG=true
fi

VCPKG_TOOLCHAIN=""
if [[ "$NEEDS_VCPKG" == true ]]; then
	command -v lipo >/dev/null 2>&1 || missing+=("lipo (part of the Xcode command line tools)")
	for candidate in "${VCPKG_ROOT:-}" "$HOME/vcpkg" /opt/vcpkg /usr/local/vcpkg; do
		[[ -n "$candidate" && -f "$candidate/scripts/buildsystems/vcpkg.cmake" ]] || continue
		VCPKG_TOOLCHAIN="$candidate/scripts/buildsystems/vcpkg.cmake"
		break
	done
	if [[ -z "$VCPKG_TOOLCHAIN" ]]; then
		missing+=("$(cat <<-EOF
			vcpkg (needed to build each architecture's dependencies) - install with:
			      git clone https://github.com/microsoft/vcpkg ~/vcpkg && ~/vcpkg/bootstrap-vcpkg.sh
			      export VCPKG_ROOT=~/vcpkg
			    No 'vcpkg install' needed: this tree has a vcpkg.json manifest.
			    For a quick host-only build that needs none of this, use --native.
		EOF
		)")
	fi
fi

if [[ ${#missing[@]} -gt 0 ]]; then
	echo "Missing prerequisites:" >&2
	for m in "${missing[@]}"; do echo "  * $m" >&2; done
	exit 1
fi

echo "Source     : $SOURCE_DIR"
echo "Build root : $BUILD_ROOT"
echo "Type       : $BUILD_TYPE   Mode: $MODE${SINGLE_ARCH:+ ($SINGLE_ARCH)}   Deployment target: $MACOSX_DEPLOYMENT_TARGET"
echo

jobs="$(sysctl -n hw.logicalcpu)"

# --------------------------------------------------------------- native build
if [[ "$MODE" == "native" ]]; then
	cmake -S "$SOURCE_DIR" -B "$BUILD_ROOT/native" \
		-DCMAKE_BUILD_TYPE="$BUILD_TYPE" "${CMAKE_EXTRA[@]+"${CMAKE_EXTRA[@]}"}"
	cmake --build "$BUILD_ROOT/native" -j "$jobs"
	binary="$BUILD_ROOT/native/openttd"
	echo
	echo "Build finished ($BUILD_TYPE, $(uname -m)): $binary"
	exit 0
fi

# ----------------------------------------------------------------- host tools
# strgen/settingsgen run during the build, so when the target architecture is not
# the host's they have to be built separately, for the host. Building for the
# host architecture alone needs none of this.
if [[ "$NEEDS_VCPKG" == true ]]; then
	echo "==> Building host tools"
	cmake -S "$SOURCE_DIR" -B "$BUILD_ROOT/host" \
		-DOPTION_TOOLS_ONLY=ON \
		-DCMAKE_BUILD_TYPE="$BUILD_TYPE"
	cmake --build "$BUILD_ROOT/host" -j "$jobs" --target tools
fi

# ------------------------------------------------------------ per-arch builds
build_arch() {
	local arch="$1" triplet="$2"
	local args=(-DCMAKE_OSX_ARCHITECTURES="$arch" -DCMAKE_BUILD_TYPE="$BUILD_TYPE")
	if [[ "$NEEDS_VCPKG" == true ]]; then
		echo
		echo "==> Building $arch (first run also builds its vcpkg dependencies)"
		args+=(-DVCPKG_TARGET_TRIPLET="$triplet"
		       -DCMAKE_TOOLCHAIN_FILE="$VCPKG_TOOLCHAIN"
		       -DHOST_BINARY_DIR="$BUILD_ROOT/host")
	else
		echo
		echo "==> Building $arch"
	fi
	cmake -S "$SOURCE_DIR" -B "$BUILD_ROOT/$arch" \
		"${args[@]}" "${CMAKE_EXTRA[@]+"${CMAKE_EXTRA[@]}"}"
	cmake --build "$BUILD_ROOT/$arch" -j "$jobs" --target openttd
}

if [[ "$MODE" == "single" ]]; then
	if [[ "$SINGLE_ARCH" == "arm64" ]]; then triplet="arm64-osx"; else triplet="x64-osx"; fi
	build_arch "$SINGLE_ARCH" "$triplet"
	binary="$BUILD_ROOT/$SINGLE_ARCH/openttd"
	echo
	echo "Build finished ($BUILD_TYPE, $SINGLE_ARCH): $binary"
	file "$binary"
	exit 0
fi

build_arch arm64 arm64-osx
build_arch x86_64 x64-osx

# ------------------------------------------------------------ universal binary
echo
echo "==> Combining both architectures with lipo"
lipo -create \
	"$BUILD_ROOT/arm64/openttd" \
	"$BUILD_ROOT/x86_64/openttd" \
	-output "$BUILD_ROOT/openttd"

echo
echo "Build finished ($BUILD_TYPE, universal): $BUILD_ROOT/openttd"
lipo -info "$BUILD_ROOT/openttd"
echo
echo "The game also needs its data files; run it from the source tree, e.g.:"
echo "  $BUILD_ROOT/openttd"

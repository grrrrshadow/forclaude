# Blueprint patch for OpenTTD 15.3

The patch's version is the **date of its last change** — in game, the
toolbar's info button (question mark, right end) shows it. It is defined as
`BLUEPRINT_PATCH_VERSION` in its own file `src/blueprint_version.h` and
updated together with each regeneration of `blueprint.patch`.

`blueprint.patch` adds the **Blueprint** feature (copy & paste of your own
transport infrastructure) to a fresh, unmodified OpenTTD 15.3 release source
tree. It is a single git patch containing 106 files (~8500 added lines),
including three binary files (the toolbar icon sheet, its launcher artwork
and the pre-built `openttd.grf`).

The helper scripts live one level up, in the `blueprint/` folder, and stay
there: drop the whole `blueprint/` folder into the source tree and run everything
from it — the scripts operate on the source tree that contains them.
`apply-patch.sh` applies the patch; `build.sh` / `run.sh` build and run on Linux,
`build.ps1` (or `build.bat`) on Windows, and `build-macos.sh` on macOS.
`build-appimage.sh` produces a portable Linux AppImage for distributing to
other machines.

## Applying

```bash
cp -r /path/to/blueprint openttd-15.3/   # fresh 15.3 release source tree
cd openttd-15.3
./blueprint/apply-patch.sh
```

Notes:

- `git` must be installed, but the source tree must **not** be a git
  repository — do not run `git init` in it. OpenTTD's build prefers git
  version detection over the release version files (`.version` / `.ottdrev`)
  and fails in a repository without release tags. `git apply` works fine on a
  plain directory, and `apply-patch.sh` also copes with the source tree
  sitting inside an enclosing repository.
- A classic `patch -p1` will **not** work: the icon sheet and `openttd.grf`
  are binary and only apply with `git apply`.
- The patch was generated against and tested on the exact 15.3 release
  source. Applying it to another version will likely produce conflicts; the
  feature has to be ported rather than patched in. Ask in the release thread
  if you want to take that on.

## Building

### Linux

```bash
./blueprint/build.sh              # Release build into build/, or:
./blueprint/build.sh Debug
./blueprint/run.sh                # start the game
```

### Linux, portable (AppImage)

For a binary that runs on other machines, not just the one that built it:

```bash
./blueprint/build-appimage.sh     # AppImage into build-appimage/
```

This builds inside a **Debian 12 container** (needs `podman` or `docker`)
rather than on the host, because an AppImage bundles libraries but never
glibc: a binary built against a recent glibc will not start on any older
distribution, however much is bundled with it. Building against Debian 12's
glibc 2.36 yields a floor of `GLIBC_2.34`, which covers Ubuntu 22.04+,
Debian 12+, Fedora 35+ and RHEL 9+.

The script runs the full test suite inside the container and refuses to
package anything if a test fails. It ends by printing the resulting glibc
floor and a ready-made command for testing the AppImage on the oldest
distribution you care about.

Rootless `podman` needs subuid/subgid ranges for your user; the script checks
this first and prints the `usermod` command if they are missing.

### macOS

```bash
./blueprint/build-macos.sh            # universal binary: Apple Silicon + Intel
./blueprint/build-macos.sh --native   # host architecture only (much faster)
./blueprint/build-macos.sh --arch x86_64
```

Needs the Xcode command line tools (`xcode-select --install`) and CMake. Either
Mac can build both slices — an Apple Silicon machine produces the Intel binary
and vice versa — because each architecture is configured with
`CMAKE_OSX_ARCHITECTURES` and the two results are combined with `lipo`, the same
way OpenTTD's own `release-macos.yml` does it.

A **universal** build additionally needs **vcpkg** (`VCPKG_ROOT` set), because
every dependency must exist for both architectures and Homebrew installs only
one at a time; the `vcpkg.json` manifest then pulls them in automatically. It
also builds host tools separately, since `strgen`/`settingsgen` have to run on
the build machine. `--native` needs none of that and is the one to use for
day-to-day development.

macOS binaries can only be built **on** macOS: Apple's SDK is licensed for Apple
hardware, so there is no practical way to cross-compile them from Linux or
Windows. Without a Mac, the remaining option is GitHub's macOS CI runners.

### Windows

```powershell
.\blueprint\build.ps1             # Release build into build-windows\
.\blueprint\build.ps1 -Config Debug -RunTests
```

or `blueprint\build.bat` from cmd.exe / Explorer, which wraps the same script
and needs no execution-policy change. Prerequisites (the script checks all of
them and names whatever is missing before doing any work):

- **Visual Studio 2022** with the *Desktop development with C++* workload
- **CMake** 3.17+ (standalone, or the VS component — must be on `PATH`)
- **vcpkg**, with `VCPKG_ROOT` set or passed via `-VcpkgRoot`
- **Git for Windows** (vcpkg uses it)

No manual `vcpkg install` is needed: the tree ships a `vcpkg.json` manifest, so
configuring installs breakpad, liblzma, libpng, lzo, opusfile and zlib by
itself. That makes the **first** build slow (~30-60 min while those compile
from source); later builds are fast.

Note the separate `build-windows\` directory. It is deliberately not `build\`,
because when the tree is shared with a Linux host (a VM share, say) `build\`
already contains a Linux CMake cache that Windows CMake cannot reuse. Building
over a VM share also works but is markedly slower than copying the tree to a
local disk first.

Library requirements are unchanged from stock OpenTTD (see COMPILING.md).
`grfcodec`/`nforenum` are **optional**: the patch ships the pre-built
`media/baseset/openttd.grf` with the 16 new toolbar icons. They are only
needed if you change the icons (regenerate the sheet with
`python3 media/baseset/openttd/openttdgui_blueprint.py`, needs Pillow; the
build then rebuilds the grf automatically when grfcodec is found). If you
add or remove a sprite, update **both** `OPENTTD_SPRITE_COUNT` in
`src/table/sprites.h` and the matching `05 15 \b N` count on the first line
of `media/baseset/openttd/openttdgui.nfo` — they must agree or `nforenum`
rejects the whole file with an unhelpful "Error on sprite N".

## Verifying

```bash
ctest --test-dir build            # all 108 tests (unit + AI/GS regression)
./build/openttd_test              # unit tests only, incl. blueprint tests
```

In game: open the Landscaping toolbar (or the button right of it in the main
toolbar) and click the blueprint button to open the Blueprint toolbar.
"Export all"/"Import all" read and write files in the `blueprint/`
subdirectory of OpenTTD's personal data directory (next to `save/`,
`screenshot/`, etc. — run `./blueprint/run.sh -d misc=2` briefly and look
for "found as personal directory" in the log if unsure which directory
that is on your system).

## What the patch contains

| Area | Files | Purpose |
|---|---|---|
| Core feature | `src/blueprint.{h,cpp}`, `src/blueprint_cmd.h` | Blueprint data structures, copy, D4 transformation, the multiplayer-safe `CMD_PASTE_BLUEPRINT` command and its serialization |
| GUI | `src/blueprint_gui.{h,cpp}`, `src/widgets/blueprint_widget.h`, `src/blueprint_version.h` | Blueprint toolbar (8 slots with content markers, player-given names, schematic+name hover previews, double-click to rename, filters, transformations, terraform tri-state, height offset); a single compact Export/Import button ("Exp/Imp") opens a 4-item dropdown menu (export/import the active slot via text, or all 8 slots via a file); an info button showing the patch version (the date of its last change, from `blueprint_version.h`); per-slot text export/import dialog with overwrite confirmation; `BlueprintFileWindow` file browser (directory navigation, click-to-select, name field) for exporting/importing all slots; ghost preview data incl. a hovering estimated-cost tooltip; hotkeys (`1`-`8`, `C`, `V`, `Q`/`E`, `F`/`G`, `M`, `X` under `[blueprint_toolbar]` in hotkeys.cfg); slots autosaved to `blueprint/autosave.txt` and restored on the next launch |
| Clipboard | `src/os/unix/unix.cpp`, `src/os/windows/win32.cpp`, `src/os/macosx/macos.mm` | `SetClipboardContents()` used by the export dialog's copy-to-clipboard button (text format: `OTTD-BP-1;` + base64) |
| File export/import | `src/fileio_type.h`, `src/fileio.cpp` | New `BLUEPRINT_DIR` subdirectory (auto-created alongside `screenshot/` etc.) holding files written by "Export all" (format: `OTTD-BPSET-1;` + base64 of all 8 slots) |
| Integration | `src/terraform_gui.cpp`, `src/toolbar_gui.cpp`, `src/viewport.cpp`, `src/window_type.h`, `src/viewport_type.h`, `src/command_type.h`, `src/command.cpp`, `src/network/network_command.cpp`, `src/rail_gui.{h,cpp}`, `src/table/sprites.h`, `src/video/video_driver.cpp`, `src/settings_type.h`, `src/table/settings/gui_settings.ini`, widget headers | Toolbar openers, ghost drawing hook, command registration, current-railtype getter, sprite constants, "Blueprint" window-title suffix, nine `gui.blueprint_*` settings persisting the toolbar toggles in openttd.cfg |
| Strings | `src/lang/*.txt` (65 files), `src/intro_gui.cpp` | All `STR_BLUEPRINT_*` strings plus translations into every shipped language except Chuvash (falls back to English); intro menu caption "OpenTTD Blueprint" (new base string, untranslated by design) |
| Icons | `media/baseset/openttd/openttdgui_blueprint.{png,py}`, `openttdgui_blueprint_launcher.{png,py}`, `openttdgui.nfo`, `CMakeLists.txt`, `media/baseset/openttd.grf(.hash)` | 16 new 20x20 GUI sprites appended to the grf's Action-5 GUI block: 15 for the blueprint toolbar's own buttons, plus the launcher icon used by the toolbar/landscaping opener buttons (`SPR_BLUEPRINT_TOOLBAR`) — two railway tracks with a rainbow arrow, drawn at native 20x20 by `openttdgui_blueprint_launcher.py` |
| Tests | `src/tests/blueprint.cpp`, `src/tests/CMakeLists.txt` | Unit tests: copy, ownership, transformation, shrinking, command serialization |

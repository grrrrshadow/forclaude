#!/usr/bin/env bash
# Run the OpenTTD binary built by ./build.sh.
#
# Usage:
#   ./run.sh                 # start the game
#   ./run.sh -D              # start a dedicated (headless) server
#   ./run.sh -d 1            # start with debug output
# All arguments are passed through to openttd (see ./run.sh -h).
set -euo pipefail

cd "$(dirname "$0")"

# The source root is either the script's own directory (when copied there) or,
# when run from blueprint/ inside the tree, the parent directory.
if [[ ! -f CMakeLists.txt && -f ../CMakeLists.txt ]]; then
	cd ..
fi

BIN="build/openttd"
if [[ ! -x "$BIN" ]]; then
	echo "Error: $BIN not found or not executable. Build it first with ./build.sh" >&2
	exit 1
fi

exec "$BIN" "$@"

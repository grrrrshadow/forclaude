# Blueprint patch for OpenTTD 15.3

Copy & paste of self-built infrastructure for OpenTTD 15.3. This archive holds
the patch and the scripts to apply and build it.

**Start with [patch/README.md](patch/README.md)** — it covers applying the patch
and building on Linux, Windows and macOS.

Quick version: drop this whole `blueprint/` folder into a clean OpenTTD 15.3
release source tree, then

```bash
cd openttd-15.3
./blueprint/apply-patch.sh
./blueprint/build.sh        # Windows: blueprint\build.ps1, macOS: build-macos.sh
./blueprint/run.sh
```

The source tree must **not** be a git repository, and the patch needs
`git apply` rather than `patch -p1` (it contains binary files).

## What is in here

| Path | Purpose |
|---|---|
| `patch/blueprint.patch` | The patch itself: 106 files against the stock 15.3 release source |
| `patch/README.md` | Applying, building, verifying — read this first |
| `apply-patch.sh` | Applies the patch to the surrounding source tree |
| `build.sh`, `run.sh` | Build and run on Linux |
| `build-appimage.sh` | Build a portable Linux AppImage (in a container) |
| `build.ps1`, `build.bat` | Build on Windows (MSVC + vcpkg) |
| `build-macos.sh` | Build on macOS (universal or native) |

## Licence

GPL v2, the same as OpenTTD itself. `patch/blueprint.patch` is the complete
corresponding source for any Blueprint binary released alongside it.

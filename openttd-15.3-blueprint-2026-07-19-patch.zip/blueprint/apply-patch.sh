#!/usr/bin/env bash
# Apply the Blueprint patch to an OpenTTD 15.3 source tree (see patch/README.md).
#
# Usage:
#   ./apply-patch.sh [path/to/openttd-15.3]   # default: the parent directory
set -euo pipefail

cd "$(dirname "$0")"
BLUEPRINT_DIR="$PWD"
PATCH="$BLUEPRINT_DIR/patch/blueprint.patch"

TARGET="${1:-..}"

if [[ ! -f "$TARGET/CMakeLists.txt" || ! -d "$TARGET/src" ]]; then
	echo "Error: '$TARGET' does not look like an OpenTTD source tree (no CMakeLists.txt / src/)." >&2
	exit 1
fi

cd "$TARGET"

# When the target tree sits inside a git repository, git apply resolves the
# patch paths from the repository root and silently skips everything outside
# the current directory; --directory pins them back to this directory.
APPLY=(git apply)
if PREFIX="$(git rev-parse --show-prefix 2>/dev/null)" && [[ -n "$PREFIX" ]]; then
	APPLY+=(--directory="$PREFIX")
fi

if "${APPLY[@]}" --reverse --check "$PATCH" 2>/dev/null; then
	echo "Patch is already applied in $PWD - nothing to do."
	exit 0
fi

if ! "${APPLY[@]}" --check "$PATCH"; then
	echo "Error: patch does not apply cleanly to $PWD (expects a fresh 15.3 release tree)." >&2
	exit 1
fi

"${APPLY[@]}" "$PATCH"

echo "Blueprint patch applied to $PWD"
echo "Build with: $BLUEPRINT_DIR/build.sh"
